USE little_lemon;

INSERT INTO customers (first_name, last_name, email, phone) VALUES
('Nayla','Putri','nayla@example.com','081234567890'),
('Andi','Saputra','andi@example.com','081298765432'),
('Siti','Aisyah','siti@example.com','081377788899');

INSERT INTO restaurant_tables (table_name, capacity, location) VALUES
('T1',2,'Window'),
('T2',4,'Center'),
('T3',6,'Private Room'),
('T4',4,'Patio');

INSERT INTO bookings (customer_id, table_id, booking_date, booking_start, booking_end, party_size, status) VALUES
(1,2,'2025-11-25','18:00:00','20:00:00',3,'CONFIRMED'),
(2,3,'2025-11-25','19:00:00','21:00:00',5,'CONFIRMED'),
(3,4,'2025-11-26','12:00:00','13:30:00',4,'CONFIRMED');
