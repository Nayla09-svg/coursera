USE little_lemon;
DELIMITER $$

CREATE PROCEDURE check_table_availability(
    IN p_table_id INT,
    IN p_date DATE,
    IN p_start TIME,
    IN p_end TIME,
    OUT p_available BOOLEAN
)
BEGIN
    DECLARE cnt INT;
    SELECT COUNT(*) INTO cnt
    FROM bookings
    WHERE table_id = p_table_id
      AND booking_date = p_date
      AND status = 'CONFIRMED'
      AND NOT (booking_end <= p_start OR booking_start >= p_end);
    SET p_available = (cnt = 0);
END$$

CREATE PROCEDURE create_booking(
    IN p_customer_id INT,
    IN p_table_id INT,
    IN p_date DATE,
    IN p_start TIME,
    IN p_end TIME,
    IN p_party_size INT,
    OUT p_booking_id INT,
    OUT p_status_msg VARCHAR(255)
)
BEGIN
    DECLARE avail BOOLEAN;
    CALL check_table_availability(p_table_id, p_date, p_start, p_end, avail);
    IF avail THEN
        INSERT INTO bookings (customer_id, table_id, booking_date, booking_start, booking_end, party_size)
        VALUES (p_customer_id, p_table_id, p_date, p_start, p_end, p_party_size);
        SET p_booking_id = LAST_INSERT_ID();
        SET p_status_msg = 'BOOKED';
    ELSE
        SET p_booking_id = NULL;
        SET p_status_msg = 'NOT_AVAILABLE';
    END IF;
END$$

CREATE PROCEDURE cancel_booking(IN p_booking_id INT, OUT p_status_msg VARCHAR(255))
BEGIN
    UPDATE bookings
    SET status = 'CANCELLED'
    WHERE booking_id = p_booking_id;
    IF ROW_COUNT() > 0 THEN
        SET p_status_msg = 'CANCELLED';
    ELSE
        SET p_status_msg = 'NOT_FOUND';
    END IF;
END$$

CREATE PROCEDURE get_customer_bookings(IN p_customer_id INT)
BEGIN
    SELECT b.*, t.table_name, c.first_name, c.last_name, c.email
    FROM bookings b
    JOIN restaurant_tables t ON b.table_id = t.table_id
    JOIN customers c ON b.customer_id = c.customer_id
    WHERE b.customer_id = p_customer_id
    ORDER BY b.booking_date, b.booking_start;
END$$

DELIMITER ;
